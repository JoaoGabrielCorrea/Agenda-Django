from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'blog/index.html')
def theRock(request):
    return render(request,'blog/sla.html')